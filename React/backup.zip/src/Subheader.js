function Subheader(props){
    return( 
        <h1>welcome to {props.subname}</h1>
    )
}
export default Subheader;