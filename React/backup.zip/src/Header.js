import Subheader from './Subheader'

function Header(props){
    return (
    <Subheader subname={props.name}/>
    )
}
export default Header;