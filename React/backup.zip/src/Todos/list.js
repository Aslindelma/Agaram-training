export default function User(){
    return(
        <>
        <table>
            <tr>
                <th>Order</th>
                <th>Items</th>
                <th>Delete</th>
            </tr>
            {todo.map((t,i)=>(
                <tr>
                    <td>{i+1}</td>
                    <td>{t}</td>
                    <td><button type="button" onClick={()=>del(t)}>x</button></td>
                </tr>
            ))}
        </table>
        </>
    )
}