import {useState} from 'react';
import AddTodo from './form';

function Todo(){
    let [todo,setTodo] = useState(["apple","orange","mango"])
    return(
        <>
        <table>
            <tr>
                <th>Order</th>
                <th>Items</th>
                <th>Delete</th>
            </tr>
            {todo.map((t,i)=>(
                <tr>
                    <td>{i+1}</td>
                    <td>{t}</td>
                    <td><button type="button" onClick={()=>del(t)}>x</button></td>
                </tr>
            ))}
        </table>
        
        <AddTodo setTodo={setTodo} todos={todo}/>
        </>

    )
}
export default Todo;