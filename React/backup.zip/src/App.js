// import logo from './logo.svg';
import './App.css';
import Button from 'react-bootstrap/Button';
import 'bootstrap/dist/css/bootstrap.min.css';
import Header from './Header';
import { useState } from 'react';
import Todo from './todo';

import User from './list.js';

function App() {
  return (
    <div className="App">
      <Todo/>
      
        
      
    </div>
  );
}

export default App;
