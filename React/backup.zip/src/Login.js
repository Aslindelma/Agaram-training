function Login(){
    return (
        <h1>Welcome to react</h1>
    )
}
export default Login;